# Cantinho dos E-books

Loja digital com Mercado Pago Checkout Pro.

## Variáveis no Render
- `MP_ACCESS_TOKEN`: Access Token do Mercado Pago (secreto)
- `APP_URL`: URL pública do serviço Render, por exemplo `https://seu-servico.onrender.com`
- `DOWNLOAD_SECRET`: uma senha aleatória longa para assinar links de download

Nunca coloque o Access Token em arquivos públicos ou no GitHub.
