const express = require('express');
const path = require('path');
const crypto = require('crypto');
const { MercadoPagoConfig, Preference, Payment } = require('mercadopago');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 10000;
const ACCESS_TOKEN = process.env.MP_ACCESS_TOKEN;
const APP_URL = process.env.APP_URL || '';
const DOWNLOAD_SECRET = process.env.DOWNLOAD_SECRET || crypto.randomBytes(32).toString('hex');

function mpClient() {
  if (!ACCESS_TOKEN) throw new Error('MP_ACCESS_TOKEN não configurado');
  return new MercadoPagoConfig({ accessToken: ACCESS_TOKEN });
}

app.get('/health', (_req, res) => res.json({ ok: true }));

app.post('/api/create-preference', async (_req, res) => {
  try {
    const client = mpClient();
    const preference = new Preference(client);
    const body = {
      items: [{
        id: 'ebook-filhos-tempo-de-hoje',
        title: 'Como Criar Meus Filhos no Tempo de Hoje',
        quantity: 1,
        unit_price: 9.90,
        currency_id: 'BRL'
      }],
      back_urls: {
        success: APP_URL ? `${APP_URL}/?status=success` : undefined,
        failure: APP_URL ? `${APP_URL}/?status=failure` : undefined,
        pending: APP_URL ? `${APP_URL}/?status=pending` : undefined
      },
      auto_return: 'approved',
      notification_url: APP_URL ? `${APP_URL}/api/webhook` : undefined,
      external_reference: 'ebook-filhos-tempo-de-hoje'
    };
    const result = await preference.create({ body });
    res.json({ id: result.id, init_point: result.init_point, sandbox_init_point: result.sandbox_init_point });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Não foi possível criar o pagamento.' });
  }
});

app.post('/api/webhook', async (req, res) => {
  // Mercado Pago pode enviar notificações de pagamento por esta URL.
  // Respondemos rapidamente e a verificação real ocorre consultando a API.
  res.sendStatus(200);
});

async function getPayment(paymentId) {
  const client = mpClient();
  const payment = new Payment(client);
  return payment.get({ id: paymentId });
}

app.get('/api/payment/:id', async (req, res) => {
  try {
    const p = await getPayment(req.params.id);
    const approved = p.status === 'approved';
    let downloadUrl = null;
    if (approved) {
      const sig = crypto.createHmac('sha256', DOWNLOAD_SECRET).update(String(p.id)).digest('hex');
      downloadUrl = `/download?payment_id=${encodeURIComponent(p.id)}&sig=${sig}`;
    }
    res.json({ status: p.status, approved, downloadUrl });
  } catch (err) {
    console.error(err);
    res.status(400).json({ error: 'Pagamento não encontrado.' });
  }
});

app.get('/download', async (req, res) => {
  try {
    const paymentId = String(req.query.payment_id || '');
    const sig = String(req.query.sig || '');
    const expected = crypto.createHmac('sha256', DOWNLOAD_SECRET).update(paymentId).digest('hex');
    if (!paymentId || !sig || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) {
      return res.status(403).send('Link inválido.');
    }
    const p = await getPayment(paymentId);
    if (p.status !== 'approved') return res.status(403).send('Pagamento ainda não aprovado.');
    return res.download(path.join(__dirname, 'private', 'ebook.pdf'), 'como-criar-meus-filhos-no-tempo-de-hoje.pdf');
  } catch (err) {
    console.error(err);
    res.status(403).send('Não foi possível liberar o e-book.');
  }
});

app.listen(PORT, () => console.log(`Cantinho dos E-books rodando na porta ${PORT}`));
